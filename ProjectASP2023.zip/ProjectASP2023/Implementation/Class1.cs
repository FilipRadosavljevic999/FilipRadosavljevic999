﻿namespace Implementation
{
    public class Class1
    {

    }
}